@echo off
rem Runs Astra Novum with load profiling on. Open a planet (Enter on a planet), wait until it shows,
rem then quit (F10). The timings of every loading stage are written to bin\load_timings.txt.
cd /d "%~dp0bin"
set ASTRA_PROFILE_LOAD=1
echo Recording load timings to bin\load_timings.txt ... open a planet, then quit with F10.
astra_client.exe --set render.validation=false > load_timings.txt 2>&1
echo Done. Send bin\load_timings.txt and bin\astra_client.log.
pause
