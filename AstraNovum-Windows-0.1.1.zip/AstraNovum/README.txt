ASTRA NOVUM 0.1.0 (prototype)
=============================

TO PLAY
  Double-click AstraNovum.exe.
  Optional: run "Create Desktop Shortcut.bat" once for a desktop icon.

  Nothing to install. Keep the folder together: AstraNovum.exe needs the bin folder
  next to it. You can put the folder anywhere (Desktop, Documents, a USB stick).

NEEDS
  Windows 10 or 11, 64-bit.
  A graphics card or chip with Vulkan 1.3 and an up-to-date driver
  (most NVIDIA, AMD and Intel graphics from about 2016 onward).
  If something is missing, AstraNovum.exe tells you what and where to get it.

FIRST TIME WINDOWS WARNS YOU
  This build is not signed, so Windows SmartScreen may say "Windows protected your PC".
  Click "More info", then "Run anyway". Some antivirus programs are cautious about new
  unsigned games too; allow bin\astra_client.exe if yours complains.

CONTROLS
  Left click       select a star (click again to open its system);
                   in a system, select a planet (click again to land)
  Shift + click    measure the distance from this star
  Drag             move the map (it stays tilted, north up)   Mouse wheel   zoom
  Enter / Esc      go into a system or planet / back out
  G  N  R          Milky Way / local neighbourhood / back to Sol
  M                measure from the selected star
  V                galaxy: true or compressed distances
                   system: spaced rings, square-root or true orbits
  F3               relations between the ten powers
  F4               briefing and history
  Space            pause            1 2 3 4   speed
  F5 / F9          save / load      F2        screenshot      F10   quit

SAVES AND LOGS
  Saves:  bin\saves\quicksave.astra
  Log:    bin\astra_client.log   (send this if something goes wrong)

LICENCES
  See the licenses folder. Star data from the HYG database (CC BY-SA 2.5) and Gaia
  (ESA/Gaia/DPAC); see licenses\star_catalogue_sources.md.
