@echo off
rem Puts an "Astra Novum" shortcut on your desktop. Run it once from this folder.
set "TARGET=%~dp0AstraNovum.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Astra Novum.lnk'); $s.TargetPath='%TARGET%'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%TARGET%,0'; $s.Description='Astra Novum'; $s.Save()"
if errorlevel 1 (
  echo Could not create the shortcut. You can still start the game with AstraNovum.exe.
) else (
  echo Done: "Astra Novum" is on your desktop.
)
pause
