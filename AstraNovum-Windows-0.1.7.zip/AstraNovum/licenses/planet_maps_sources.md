# Surface maps of real Solar System bodies

Built by `tools/prepare_body_maps.py`; regenerate rather than edit. Equirectangular,
longitude -180 to 180 from left to right, north up.

| Bodies | Source | Licence |
|---|---|---|
| Mars, Phobos, Deimos, Io, Europa, Ganymede, Callisto, Titan, Enceladus, Venus, Pluto, Charon | NASA 3D Resources, "Images and Textures" (github.com/nasa/NASA-3D-Resources). Greyscale mosaics are tinted toward each body's colour; gaps in coverage are filled with the surrounding colour. | NASA: "free and without copyright"; NASA media usage guidelines apply (no implied endorsement, no NASA insignia). |
| Earth.jpg | NASA Blue Marble (Visible Earth), 4096 x 2048, as published in the three.js examples (github.com/mrdoob/three.js, examples/textures/planets/earth_day_4096.jpg). | NASA imagery: public domain; NASA media usage guidelines apply. three.js: MIT. |
| Moon (visible hemisphere) | Apollo photograph of the full Moon, NASA 3D Resources ("Moon"), reprojected. The hemisphere not in the photograph is procedural highland. | NASA, as above. |
| Mercury, Ceres, Triton | Procedural (`tools/procedural_surfaces.py`), toned to the real body. No usable public-domain map was reachable when the files were built. | Generated for Astra Novum. |
| Jupiter, Saturn, Uranus, Neptune | Painted at 2048 x 1024 by `tools/enhance_gas_giants.py`: each planet's real band latitudes and true colours (Juno, Cassini and Voyager imagery as reference), torn into eddies by sheared domain-warped turbulence, wound round its named storms (Great Red Spot, white ovals, Neptune's dark spot). The public maps were too small and, for Saturn, badly tinted. | Generated for Astra Novum. |

Venus's map is a radar mosaic of the surface (Magellan), which the clouds hide in reality;
the game draws Venus with a dense cloud layer over it.

## Earth's clouds, night lights, provinces and cities

| File | Source | Licence |
|---|---|---|
| Earth_clouds.jpg, Earth_lights.jpg | From Project Helios (the author's own Age of Civilizations II mod), where they were prepared from NASA's Blue Marble cloud and Black Marble night-lights imagery. Converted to greyscale. | NASA imagery: public domain; NASA media usage guidelines apply. |
| Earth_provinces.png, ../../data/earth/*.tsv | Built by `tools/prepare_earth_provinces.py` from Natural Earth 1:10m admin-1 states and provinces and 1:50m populated places (naturalearthdata.com, github.com/nvkelso/natural-earth-vector). The 2240 federal regions and their names are Astra Novum's own. | Natural Earth: public domain. |

## Earth's water, height and rivers; generated-world swatches

| File | Source | Licence |
| --- | --- | --- |
| Earth_water.png, Earth_height.png | From Project Helios (the author's own mod): its water mask and elevation map, thresholded and converted by `tools/prepare_surface_swatches.py`. | The author's own work; elevation derived from public-domain NASA/USGS data. |
| Earth_rivers.png | Rasterised by `tools/prepare_surface_swatches.py` from Project Helios's river lines (globe/rivers.txt). | The author's own work. |
| ../swatches/biomes.jpg | Twelve 512 x 384 crops of the Blue Marble image above (Sahara, Kazakh steppe, Zambian savannah, Amazon, Alaska North Slope, Afghan ranges, Western Australia and others), water painted out. Used to paint generated worlds. | NASA imagery: public domain. |

## Mars in 2240 (terraformed)

| File | Source | Licence |
| --- | --- | --- |
| Mars_terraformed.jpg, Mars_water.png, Mars_height.png | Built by `tools/prepare_mars_terraformed.py`: the sea stands at -3200 m on the areoid of NASA's Mars Global Surveyor MOLA topography (32 px/degree copy from the Mars Climate Database, via github.com/andrebelem/PlanetaryMaps); colour from Mars.jpg above, darkened and given moss along the new shores. | MOLA: NASA, public domain. |

| Venus_clouds.jpg | Venus.jpg above, recoloured to the pale cream of Venus's cloud deck as seen from space (faint banding kept from the map). | As Venus.jpg. |

## Earth in 2240: no ice, the sea 70 m higher

| File | Source | Licence |
| --- | --- | --- |
| Earth.jpg, Earth_water.png, Earth_height.png | Rebuilt by `tools/prepare_earth_2240.py` from today's maps (kept in tools/earth_today/): land the sea can reach below +70 m drowns, judged from Project Helios's height map calibrated against ETOPO1 (10 arc-minute grid from fatiando-data/earth-topography-10arcmin, from NOAA NCEI). The ice sheets are gone: the polar coasts follow the shape of the bedrock maps (Bedmap2, BedMachine) by hand, and bare ground is painted from the biome swatches. | ETOPO1: NOAA, public domain (fatiando-data packaging CC-BY 4.0). Others as above. |
| Earth_provinces.png, ../../data/earth/*.tsv | `tools/prepare_earth_provinces.py`, as above, on the 2240 coastline: in North America, Eastern Europe, the Near East and Central Asia, Africa, South America and South-East Asia today's subdivisions are regrouped into new regions across today's country borders (every line is still a real one); cities under the sea are gone. | Natural Earth: public domain. |

## Earth's polar lands without ice, and the 2240 ecology

| File | Source | Licence |
| --- | --- | --- |
| Greenland in Earth.jpg / Earth_water.png | The bed-elevation picture the author supplied (BedMachine Greenland, Morlighem et al.: NSIDC), georeferenced in its EPSG:3413 grid and fitted to today's coast; bed below sea level is sea (`tools/earth_today/greenland_bedmachine.jpg`). | BedMachine: NASA/NSIDC data, free to use with citation. |
| Antarctica in Earth.jpg / Earth_water.png | The ice-free Antarctica relief picture the author supplied, fitted to today's coast by rotation, scale and position (`tools/earth_today/antarctica_icefree.jpg`); its colours paint the bare land. | Supplied by the author for the game. |
| Earth_ecology.png | `tools/prepare_earth_ecology.py`: biomes from the satellite colours, latitude and height (Whittaker's diagram, 3 C warmer), the 2240 coast. | Derived from the maps above. |
| Mars_provinces.png, ../../data/mars/*.tsv | `tools/prepare_mars_provinces.py`: Mars's lands cut along MOLA topography (least-cost borders over slope), named for real features (IAU nomenclature). | Derived from MOLA (NASA, public domain). |

## 8K pass (November 2026)

- **Earth.jpg** (8192 x 4096): the 2240 map (tools/prepare_earth_2240.py) with the fine detail of
  the 8K Blue Marble put back where the ground is unchanged (tools/prepare_earth_8k.py). 8K source:
  Solar System Scope `8k_earth_daymap.jpg`, from NASA Blue Marble; CC-BY 4.0.
- **Earth_lights.jpg** (8192 x 4096): today's lights from Solar System Scope `8k_earth_nightmap.jpg`
  (NASA Black Marble / VIIRS; CC-BY 4.0), drowned coastal lights moved to the new coasts, plus 2240
  growth from the Rust grower (rust/astra_bake/src/lights.rs): towns in a Zipf-like size mix on
  road networks, after Small & Elvidge (VIIRS night-light network structure) and Small et al.
  2011 (spatial scaling of stable night lights).
- **Mars_terraformed.jpg** (8192 x 4096): the terraformed map with the detail of Solar System Scope
  `8k_mars.jpg` (NASA/USGS Viking mosaic; CC-BY 4.0) transferred as a brightness ratio on land
  (tools/prepare_mars_8k.py). Mars' night lights are grown at load time by the same Rust grower.
