ASTRA NOVUM - HD TEXTURES (8K)
Unzip this over your Astra Novum folder (say Yes to replace). It swaps in 8192 x 4096 maps for
Earth (day), Earth (night lights, with the 2240 Siberian growth) and terraformed Mars.
Needs about 500 MB more graphics memory. To go back, unzip the main game again.
